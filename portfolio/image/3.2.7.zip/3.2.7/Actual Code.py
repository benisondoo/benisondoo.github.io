'''
Partners: Jessie Houng, Benison Doo
Project: 3.2.7 Investigating with Data
Clients: Roy Johung, Anderson Wu
'''
#import libraries required
import numpy as np
import matplotlib.pyplot as plt
import os.path as os

directory = os.dirname(os.abspath(__file__)) #changes directory
filename = os.join(directory, 'sportdata.csv') # Build an absolute filename from directory + filename
datafile = open(filename,'r') #opens data file
data = datafile.readlines()
streakLostList = [] #empty lists created to store proportion of wins and losses
lostList = []

for line in data:
    opponent, outcome, streak = line.split(',') #names each column in the csv file, separated by commas
    streak = streak[0:-1] #ignores last two characters in streak column (/n)
    if str(streak) == 'lost 4':
        streakLostList += 'L' #appends L to streakLostList when the team loses their 4th game in a row
    elif str(streak) == 'lost 3':
        streakLostList += 'T' #appends W to streakLostList when the team loses their 3rd game in a row
    if str(outcome) == 'W': 
        lostList += 'W'#appends W to to lostList (second pie chart) when team wins any game during the seasons
    elif str(outcome) == 'L':
        lostList += 'L'#appends L to to lostList when team loses any game during the seasons
fig, ax = plt.subplots(1, 2, figsize = (20,20)) #sets pie chart sizes
wins = streakLostList.count('T') - streakLostList.count('L') #sets the frequency of losses/wins after winning 3 consecutive games
labels = 'Proportion of Losing A Game After Losing Streak', 'Proportion of Winning A Game After Losing Streak' #labels each portion of the pie chart
sizes = [streakLostList.count('L'), wins] #sets the proportion of the variables on the pie chart
colors = ['lightcoral','yellowgreen'] #sets the colors of the pie charts
labels2 = 'Proportion of Losses', 'Proportion of Wins'#sets the title for frequency of losses/wins
sizes2 = [lostList.count('L'), lostList.count('W')] #sets the proportion of the variables on the second pie chart
ax[0].pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', shadow=True, startangle=140,) #defines parameters for first pie chart
ax[1].pie(sizes2, labels=labels2, colors=colors, autopct='%1.1f%%', shadow=True, startangle=140,) #defines parameters for second pie chart

for i in range(0,2):
    ax[i].set_aspect(1) #sets ratio of the image
    plt.axis('equal') #sets position of pie charts
    plt.show(ax[i]) #displays the pie charts